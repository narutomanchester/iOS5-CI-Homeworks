//
//  CGPointUtil.swift
//  Dzqua
//
//  Created by admin on 9/4/16.
//  Copyright © 2016 Techkids. All rights reserved.
//

import Foundation

import SpriteKit

extension CGPoint{
    func add(p : CGPoint) -> CGPoint {
        let retX = self.x + p.x
        let retY = self.y + p.y
        return CGPoint(x: retX, y: retY)
    }
    
    func subtract(p : CGPoint) -> CGPoint {
        return CGPoint(x: self.x - p.x, y: self.y - p.y)
    }
    
    func muti(p: CGPoint) -> CGPoint {
        return CGPoint(x: self.x * p.x, y: self.y * p.y)
    }
    
    
}