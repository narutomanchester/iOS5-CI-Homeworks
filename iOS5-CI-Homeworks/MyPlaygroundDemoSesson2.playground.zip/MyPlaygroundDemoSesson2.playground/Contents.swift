//: Playground - noun: a place where people can play

import UIKit

import SpriteKit

extension CGPoint{
    func multi(a : Int) -> CGPoint {
        return CGPoint(x: (Int)(self.x) * a, y: (Int)(self.y) * a)
    }
    func dis(p : CGPoint) -> CGFloat {
        let y = (self.x-p.x)*(self.x-p.x) + (self.y-p.y)*(self.y-p.y)
        let x = sqrt(y)
        return x
    }
    func vectorNormalize() -> CGPoint {
        let xx = sqrt(self.x * self.x + self.y * self.y)
        return CGPoint(x: self.x/xx, y: self.y/xx)
    }
}






let A = CGPoint(x: 21, y: 21)
print("diem A : \(A)")

let B = CGPoint(x: 977, y: 9777)
print("diem B : \(B)")

let C = A.multi(113)
print("nhan diem A voi 113 : \(C)")

let D = A.dis(B)
print("khoang cach A den B bang: \(D)")

let E = A.vectorNormalize()
print("Chuan hoa Vector A: \(E)")

